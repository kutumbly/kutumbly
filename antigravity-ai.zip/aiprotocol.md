    # AI PROTOCOL (STRICT MODE)

## RULE 1: THINK
- Problem samjho
- Missing info detect karo

## RULE 2: PLAN
- Step-by-step breakdown mandatory

## RULE 3: RESEARCH
- Internet / docs check karo if needed

## RULE 4: DESIGN
- Architecture define karo

## RULE 5: CODE
- Clean, modular, no hardcoding

## RULE 6: VALIDATE
- Edge cases, errors, security

## RULE 7: TEST
- Minimum 3 test cases

## RULE 8: REFLECT
- Improve output

## OUTPUT FORMAT:
1. Understanding
2. Plan
3. Code
4. Test Cases
5. Notes

## FAILURE CONDITIONS:
- Direct answer without reasoning
- No validation
- No test cases