// Company: Prathamone
// System: GAP Engine

const { enforceProtocol } = require("../protocol/enforcer");
const { runAnthropicLayer } = require("../anthropic/loop");

async function callLLM(prompt) {
  // 🔥 Replace with OpenAI / Claude / API
  return "LLM RESPONSE: " + prompt;
}

async function runGAP(userInput) {
  const finalPrompt = enforceProtocol(userInput);

  let output = await callLLM(finalPrompt);

  output = await runAnthropicLayer(output, callLLM);

  return output;
}

module.exports = { runGAP };
