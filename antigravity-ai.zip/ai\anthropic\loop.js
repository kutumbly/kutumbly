// Company: Prathamone

const { critic } = require("./critic");
const { improver } = require("./improver");

async function runAnthropicLayer(output, callLLM, maxLoops = 2) {
  let current = output;

  for (let i = 0; i < maxLoops; i++) {
    const critique = await critic(current, callLLM);

    if (critique.includes("No issues")) break;

    current = await improver(current, critique, callLLM);
  }

  return current;
}

module.exports = { runAnthropicLayer };
