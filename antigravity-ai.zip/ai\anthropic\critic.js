// Company: Prathamone

async function critic(output, callLLM) {
  const prompt = `
Review this output:
- Check correctness
- Missing logic
- Security issues
- Protocol violations

Output:
${output}

Respond:
Issues:
- ...
Improvements:
- ...
`;

  return await callLLM(prompt);
}

module.exports = { critic };
